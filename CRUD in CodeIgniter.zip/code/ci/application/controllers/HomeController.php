<?php

class HomeController extends CI_Controller{
    function index(){
        $this->load->view('addUser');
    }

    function registerUser(){
       
            $insertArray = [
                'name'=> $this->input->post('user'),
                'email'=> $this->input->post('email'),
                'password'=>$this->input->post('password'),
                'address'=>$this->input->post('add'),
                'phone'=>$this->input->post('phone'),
            ];

            $this->load->model('HomeModel');
            $status = $this->HomeModel->register($insertArray);
            if($status == true){
                $data['message'] = "Successfully Registered";
            }else{
                $data['message'] = "Please Try Again";
            }
            $this->load->view('addUser',$data);
    }
    function viewUser(){
        $this->load->model('HomeModel');
        $data['userinfo'] = $this->HomeModel->getAllUsers();
        $this->load->view('viewUsers',$data);
    }
    
    function deleteUser($userId){
        $this->load->model('HomeModel');
        $status = $this->HomeModel->delete_user($userId);
        if($status == true){
            $data['message'] = "Successfully Deleted";
        }else{
            $data['message'] = "Please Try Again";
        }
        $data['userinfo'] = $this->HomeModel->getAllUsers();
        $this->load->view('viewUsers',$data);
    }

    function editUser($userId){
       
        $this->load->model('HomeModel');
        $data['user'] = $this->HomeModel->getSingleUser($userId);
        $this->load->view('updateForm',$data);
    }
    function updateUser(){
        $this->load->model('HomeModel');
        
            $setArray = [
                'name' => $this->input->post('name'),
                 'address' => $this->input->post('add'),
                  'phone' => $this->input->post('phone'),
                 
            ];
            $userId = $this->input->post('userId');
            $status = $this->HomeModel->update_User($setArray,$userId);
            if($status == true){
                $data['message'] = "Successfully Updated";
            }else{
                $data['message'] = "Please Try Again";
            }
            $data['userinfo'] = $this->HomeModel->getAllUsers();
            $this->load->view('viewUsers',$data);
        
    }
}

?>