<?php

class HomeModel extends CI_Model{
    
    function register($insertArr){
        if($this->db->insert('reg',$insertArr)){
            return true;
        }else{
            return false;
        }
    }
    function getAllUsers(){
       
        $response = $this->db->get('reg');
        // --fetch user data--
        $data = $response->result_array();   
        return $data;
    }
    function delete_user($id){
        
        $this->db->where('id',$id);
        if($this->db->delete('reg')){
            return true;
        }else{
            return false;
        }
    }

    function getSingleUser($id){
        
        $this->db->where('id',$id);
        $data = $this->db->get('reg');
        return $data->row_array();
    }

    function update_User($set, $id){
        $this->db->set($set);
        $this->db->where('id',$id);
        if($this->db->update('reg')){
            return true;
        }else{
            return false;
        }
    }
}

?>