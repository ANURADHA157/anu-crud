<!DOCTYPE html>
<html lang="en">
<head>
    <title>View User</title>
</head>
<body>
    <a href="<?php echo base_url(); ?>">Add User </a> 
    &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="<?php echo base_url('view'); ?>">View User</a>
    <hr>
    <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
             <th>Address</th>
              <th>Phone</th>
            <th>Action</th>
        </tr>
        <?php
        foreach($userinfo as $user){
            ?>
            <tr>
                <td><?php echo $user['id']; ?></td>
                <td><?php echo $user['name']; ?></td>
                <td><?php echo $user['email']; ?></td>
                <td><?php echo $user['address']; ?></td>
                  <td><?php echo $user['phone']; ?></td>
                <td> <a href="<?php echo base_url('delete/'.$user['id']); ?>">Delete</a>
                <a href="<?php echo base_url('edit/'.$user['id']); ?>">Edit</a>
            
                </td>
            </tr>
            <?php
        }
        ?>
    </table>
    
</body>
</html>