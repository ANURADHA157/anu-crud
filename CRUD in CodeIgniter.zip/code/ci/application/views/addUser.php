<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add User</title>
</head>
<body>
    <a href="<?php echo base_url(); ?>">Add User </a> 
    &nbsp;&nbsp;&nbsp;&nbsp;
    <a href="<?php echo base_url('view'); ?>">View User</a>
    <hr>
    <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>
    <form action="<?php echo base_url('registration'); ?>" method="POST">
        Name : <br>
        <input type="text" name="user">
        <br>
      Email-ID : <br>
        <input type="text" name="email">
        <br>
       Password : <br>
        <input type="password" name="password" >
        <br>
          Address : <br>
        <input type="text" name="add" >
        <br>
         Phone : <br>
        <input type="number" name="phone" >
        <br>
        <input type="submit" name="submitbtn" value="ADD">
        <input type="reset" name="resetbtn">
        <br>
    </form>
    
</body>
</html>